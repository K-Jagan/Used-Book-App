
# Screenshots
<div>
<img src="images/loading.png" alt="phone image" width="200px" />
<img src="images/login.png" alt="phone image" width="200px" />
<img src="images/signup.png" alt="phone image" width="200px" />
<img src="images/home.png" alt="phone image" width="200px" />
<img src="images/details.png" alt="phone image" width="200px" />
<img src="images/navigation.png" alt="phone image" width="200px" />
<img src="images/my_ad.png" alt="phone image" width="200px" />
<img src="images/new_ad.png" alt="phone image" width="200px" />
</div>


